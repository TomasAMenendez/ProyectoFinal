export type JuegoId = 'sombras' | 'adivina' | 'contar'
export type ResultadoPartida = 'gano' | 'perdio'
export type Pantalla = 'nombre' | 'menu' | JuegoId

export interface FichaSombra {
  id: string
  nombreVisible: string
  pistas: string[]
  silueta: string
}

export interface FichaAdivina {
  id: string
  nombreCorrecto: string
  pistas: string[]
  imagen: string
}

export interface EjercicioContar {
  id: string
  imagen: string
  pregunta: string
  cantidad: number
}

export interface ResultadoVisita {
  nombre: string
  juego: JuegoId
  resultado: ResultadoPartida
  fechaHora: string
}
