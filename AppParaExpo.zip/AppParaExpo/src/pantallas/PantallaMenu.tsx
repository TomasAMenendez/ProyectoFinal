import { ejerciciosContar, fichasAdivina, fichasSombra, urlImagen } from '../datos/catalogos'
import type { JuegoId } from '../juegos/comun/tipos'
import { LogoTeo } from '../componentes/LogoTeo'
import '../estilos/menu.css'

const TARJETAS: { id: JuegoId; titulo: string; imagen: string }[] = [
  { id: 'sombras', titulo: 'SOMBRAS', imagen: fichasSombra()[0]?.silueta ?? '' },
  { id: 'adivina', titulo: 'ADIVINA EL OBJETO', imagen: fichasAdivina()[2]?.imagen ?? '' },
  { id: 'contar', titulo: 'CONTAR', imagen: ejerciciosContar()[1]?.imagen ?? '' },
]

export function PantallaMenu({ nombre, onElegir }: { nombre: string; onElegir: (juego: JuegoId) => void }) {
  return (
    <section className="pantalla presentacion">
      <LogoTeo compacto />
      <h1>Hola, {nombre}</h1>
      <p className="subtitulo">Elegí un juego</p>
      <div className="rejilla-menu">
        {TARJETAS.map((tarjeta) => (
          <button key={tarjeta.id} type="button" className={`tarjeta-juego tarjeta-${tarjeta.id}`} onClick={() => onElegir(tarjeta.id)}>
            <img src={urlImagen(tarjeta.imagen)} alt="" />
            <span>{tarjeta.titulo}</span>
          </button>
        ))}
      </div>
    </section>
  )
}
