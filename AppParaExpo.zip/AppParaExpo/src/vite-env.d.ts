/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SHEETS_URL?: string
  readonly VITE_SHEETS_API_KEY?: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}

declare const __REGISTRO_HABILITADO__: boolean
declare const __ENTREGA_OFFLINE__: boolean
