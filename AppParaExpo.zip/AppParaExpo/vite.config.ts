import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vitest/config'
import { viteSingleFile } from 'vite-plugin-singlefile'

const raiz = path.dirname(fileURLToPath(import.meta.url))

export default defineConfig(({ mode }) => {
  const offline = mode === 'offline'
  return {
    base: './',
    plugins: [
      react(),
      ...(offline ? [viteSingleFile()] : []),
      {
        name: 'renombrar-html-offline',
        apply: 'build',
        closeBundle() {
          if (!offline) return
          const origen = path.join(raiz, 'offline', 'index.html')
          const destino = path.join(raiz, 'offline', 'AppParaExpo-Offline.html')
          if (!fs.existsSync(origen)) return
          fs.rmSync(destino, { force: true })
          fs.renameSync(origen, destino)
        },
      },
    ],
    resolve: {
      alias: {
        '@registro-config': path.join(
          raiz,
          'src',
          'servicios',
          offline ? 'config.offline.ts' : 'config.hosted.ts',
        ),
      },
    },
    define: {
      __REGISTRO_HABILITADO__: offline ? 'false' : 'true',
      __ENTREGA_OFFLINE__: offline ? 'true' : 'false',
    },
    build: {
      outDir: offline ? 'offline' : 'dist',
      emptyOutDir: true,
      assetsInlineLimit: offline ? 100_000_000 : 4096,
      cssCodeSplit: false,
    },
    test: {
      environment: 'node',
      include: ['src/**/*.test.ts'],
    },
  }
})
